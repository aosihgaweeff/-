﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class HelpForm : Form
    {
        bool fsize = true;

        public HelpForm()
        {
            InitializeComponent();
            this.Opacity = 0.7;
            this.Text = "Задание №2 выполнили Никулин Д.В. и Ситало Р.В.; Номер варианта 3, дата выполнения 21.04.2024";
            this.ControlBox = false;
        }

        private void CloseBtnClick(object sender, EventArgs e)
        {
            this.Close();
        }
        private void ScaleBtnClick(object sender, EventArgs e)
        {

            if (fsize)
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                fsize = false;
            }
            else
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Normal;
                fsize = true;
            }
        }

        private void MinBtnClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
