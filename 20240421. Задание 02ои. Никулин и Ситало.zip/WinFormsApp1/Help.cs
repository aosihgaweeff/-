﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Help : Form
    {
        bool fsize = true;

        public Help()
        {
            InitializeComponent();
            this.Opacity = 0.7;
            this.Text = "Задание №2 выполнили Никулин Д.В. и Ситало Р.В.; Номер варианта 3, дата выполнения 21.04.2024";
            this.ControlBox = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (fsize)
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                fsize = false;
            }
            else
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Normal;
                fsize = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
