﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class PaintForm : Form
    {
        bool fsize = true;
        private Bitmap drawingBitmap;
        Brush yellow_brush = new SolidBrush(Color.Yellow);
        Brush red_brush = new SolidBrush(Color.Red);
        Brush black_brush = new SolidBrush(Color.Black);
        Brush green_brush = new SolidBrush(Color.Green);
        Brush blue_brush = new SolidBrush(Color.Blue);
        
        public PaintForm()
        {
            InitializeComponent();
            this.Text = "Задание №2 выполнили Никулин Д.В. и Ситало Р.В.; Номер варианта 3, дата выполнения 21.04.2024";
            drawingBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            this.ControlBox = false;
        }


        private void CloseBtnClick(object sender, EventArgs e)
        {
            this.Close();
        }
        
        private void ScaleBtnClick(object sender, EventArgs e)
        {

            if (fsize)
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                fsize = false;
            }
            else
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Normal;
                fsize = true;
            }
        }

        private void MinBtnClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            drawingBitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);

            string selectedFigure = comboBox1.SelectedItem.ToString();

            using (Graphics g = Graphics.FromImage(drawingBitmap))
            {

                Pen pen = new Pen(Color.Black, 2);

                switch (selectedFigure)
                {
                    case "Эллипс":
                        g.DrawEllipse(pen, 50, 50, 100, 70);
                        g.FillEllipse(green_brush, 50, 50, 100, 70);
                        break;
                    case "Прямоугольный треугольник":
                        Point[] rt_points = { new Point(50, 50), new Point(150, 50), new Point(50, 150), new Point(50, 50) };
                        g.DrawLines(pen, rt_points);
                        g.FillPolygon(blue_brush, rt_points);
                        break;
                    case "Правильный шестиугольник":
                        
                        int hexagon_centerX = 150; 
                        int hexagon_centerY = 150; 
                        int hexagon_radius = 50; 
                        int hexagon_sides = 6; 

                        Point[] hexagonPoints = new Point[hexagon_sides];
                        for (int i = 0; i < hexagon_sides; i++)
                        {
                            double angle = 2 * Math.PI / hexagon_sides * i;
                            int x = (int)(hexagon_centerX + hexagon_radius * Math.Cos(angle));
                            int y = (int)(hexagon_centerY + hexagon_radius * Math.Sin(angle));
                            hexagonPoints[i] = new Point(x, y);
                        }

                        g.DrawPolygon(pen, hexagonPoints);
                        g.FillPolygon(blue_brush, hexagonPoints);
                        break;
                    case "Квадрат":
                        g.DrawRectangle(pen, 50, 50, 100, 100);
                        g.FillRectangle(yellow_brush, 50, 50, 100, 100);
                        break;
                    case "Прямоугольник":
                        g.DrawRectangle(pen, 50, 50, 150, 100);
                        g.FillRectangle(black_brush, 50, 50, 150, 100);
                        break;
                    case "Равносторонний треугольник":
                        Point top = new Point(150, 50);  
                        Point bottomLeft = new Point(50, 150);  
                        Point bottomRight = new Point(250, 150); 

                        g.DrawLine(pen, top, bottomLeft); 
                        g.DrawLine(pen, bottomLeft, bottomRight);  
                        g.DrawLine(pen, bottomRight, top);
                        Point[] trianglePoints = { top, bottomLeft, bottomRight };
                        
                        g.FillPolygon(red_brush, trianglePoints);
                        break;
                    case "Трапеция":
                        Point[] Trapezium = new Point[]
                        {
                            new Point(50, 100),
                            new Point(150, 100),
                            new Point(200, 200),
                            new Point(0, 200) 
                        };

                        
                        g.DrawPolygon(pen, Trapezium);
                        g.FillPolygon(yellow_brush, Trapezium);
                        break;
                    case "Окружность":
                        int centerX = 150;
                        int centerY = 150;
                        int radius = 50;
                        int diameter = radius * 2;

                        int topLeftX = centerX - radius;
                        int topLeftY = centerY - radius;

                        g.DrawEllipse(pen, topLeftX, topLeftY, diameter, diameter);
                        break;
                    case "Ромб":
                        Point[] rhombusPoints = new Point[]
                        {
                            new Point(150, 50),
                            new Point(250, 150), 
                            new Point(150, 250), 
                            new Point(50, 150) 
                        };

                        
                        g.DrawPolygon(pen, rhombusPoints);
                        g.FillPolygon(black_brush, rhombusPoints);
                        break;
                    case "Равнобедренный треугольник":
                        Point[] isoscelesTrianglePoints = new Point[]
                        {
                            new Point(150, 50), 
                            new Point(100, 150), 
                            new Point(200, 150) 
                        };

                        g.DrawPolygon(pen, isoscelesTrianglePoints);
                        g.FillPolygon(yellow_brush, isoscelesTrianglePoints);
                        break;
                    case "Параллелограмм":
                        Point[] parallelogramPoints = new Point[]
                        {
                            new Point(50, 50),
                            new Point(300, 50),
                            new Point(250, 150),
                            new Point(0, 150) 
                        };

                        g.DrawPolygon(pen, parallelogramPoints);
                        g.FillPolygon(red_brush, parallelogramPoints);
                        break;
                    case "Круг":
                        int x_round = 50; 
                        int y_round = 50; 
                        int diameter2 = 100; 

                        g.DrawEllipse(pen, x_round, y_round, diameter2, diameter2);

                        g.FillEllipse(black_brush, x_round, y_round, diameter2, diameter2);
                        break;
                }
            }

            pictureBox1.Image = drawingBitmap;
        }

    }
}
