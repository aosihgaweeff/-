﻿namespace WinFormsApp1
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(674, 12);
            button1.Name = "button1";
            button1.Size = new Size(40, 29);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += CloseClick;
            // 
            // button2
            // 
            button2.Location = new Point(720, 12);
            button2.Name = "button2";
            button2.Size = new Size(40, 29);
            button2.TabIndex = 1;
            button2.Text = "□";
            button2.UseVisualStyleBackColor = true;
            button2.Click += ScaleClick;
            // 
            // button3
            // 
            button3.Location = new Point(766, 12);
            button3.Name = "button3";
            button3.Size = new Size(40, 29);
            button3.TabIndex = 2;
            button3.Text = "_";
            button3.UseVisualStyleBackColor = true;
            button3.Click += MinClick;
            // 
            // button4
            // 
            button4.Location = new Point(209, 63);
            button4.Name = "button4";
            button4.Size = new Size(307, 272);
            button4.TabIndex = 3;
            button4.Text = "Start";
            button4.UseVisualStyleBackColor = true;
            button4.Click += PaintFormClick;
            // 
            // button5
            // 
            button5.Location = new Point(325, 380);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 4;
            button5.Text = "Help";
            button5.UseVisualStyleBackColor = true;
            button5.Click += HelpFormClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(818, 459);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;

    }
}
