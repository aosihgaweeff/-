﻿namespace WinFormsApp1
{
    partial class PaintForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            comboBox1 = new ComboBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(674, 12);
            button1.Name = "button1";
            button1.Size = new Size(40, 29);
            button1.TabIndex = 0;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = true;
            button1.Click += CloseBtnClick;
            // 
            // button2
            // 
            button2.Location = new Point(720, 12);
            button2.Name = "button2";
            button2.Size = new Size(40, 29);
            button2.TabIndex = 1;
            button2.Text = "□";
            button2.UseVisualStyleBackColor = true;
            button2.Click += ScaleBtnClick;
            // 
            // button3
            // 
            button3.Location = new Point(766, 12);
            button3.Name = "button3";
            button3.Size = new Size(40, 29);
            button3.TabIndex = 2;
            button3.Text = "_";
            button3.UseVisualStyleBackColor = true;
            button3.Click += MinBtnClick;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Эллипс", "Прямоугольный треугольник", "Правильный шестиугольник", "Квадрат", "Прямоугольник", "Равносторонний треугольник", "Трапеция", "Окружность", "Ромб", "Равнобедренный треугольник", "Параллелограмм", "Круг" });
            comboBox1.Location = new Point(591, 61);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(248, 28);
            comboBox1.TabIndex = 3;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(199, 102);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(364, 274);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // Paint
            // 
            ClientSize = new Size(860, 453);
            Controls.Add(pictureBox1);
            Controls.Add(comboBox1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Paint";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }


        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}