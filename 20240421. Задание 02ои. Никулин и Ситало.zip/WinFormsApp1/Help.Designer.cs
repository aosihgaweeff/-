﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    partial class HelpForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            clsbtn = new Button();
            sclbtn = new Button();
            minbtn = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            clsbtn.Location = new Point(842, 15);
            clsbtn.Margin = new Padding(4, 4, 4, 4);
            clsbtn.Name = "button1";
            clsbtn.Size = new Size(50, 36);
            clsbtn.TabIndex = 0;
            clsbtn.Text = "X";
            clsbtn.UseVisualStyleBackColor = true;
            clsbtn.Click += CloseBtnClick;
            // 
            // button2
            // 
            sclbtn.Location = new Point(900, 15);
            sclbtn.Margin = new Padding(4, 4, 4, 4);
            sclbtn.Name = "button2";
            sclbtn.Size = new Size(50, 36);
            sclbtn.TabIndex = 1;
            sclbtn.Text = "□";
            sclbtn.UseVisualStyleBackColor = true;
            sclbtn.Click += ScaleBtnClick;
            // 
            // button3
            // 
            minbtn.Location = new Point(958, 15);
            minbtn.Margin = new Padding(4, 4, 4, 4);
            minbtn.Name = "button3";
            minbtn.Size = new Size(50, 36);
            minbtn.TabIndex = 2;
            minbtn.Text = "_";
            minbtn.UseVisualStyleBackColor = true;
            minbtn.Click += MinBtnClick;
            // 
            // Help
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1021, 562);
            Controls.Add(clsbtn);
            Controls.Add(sclbtn);
            Controls.Add(minbtn);
            Margin = new Padding(4, 4, 4, 4);
            Name = "Help";
            Text = "Help";
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button clsbtn;
        private System.Windows.Forms.Button sclbtn;
        private System.Windows.Forms.Button minbtn;
        
    }
}