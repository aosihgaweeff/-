using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class MainForm : Form
    {
        bool fsize = true;
        public MainForm()
        {
            InitializeComponent();
            this.Text = "������� �2 ��������� ������� �.�. � ������ �.�.; ����� �������� 3, ���� ���������� 21.04.2024";
            this.ControlBox = false;
        }


        private void CloseClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ScaleClick(object sender, EventArgs e)
        {

            if (fsize)
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                fsize = false;
            }
            else
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Normal;
                fsize = true;
            }
        }

        private void MinClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void PaintFormClick(object sender, EventArgs e)
        {
            PaintForm form2 = new PaintForm();
            this.Hide();
            form2.Show();
        }

        private void HelpFormClick(object sender, EventArgs e)
        {
            HelpForm helpfrm = new HelpForm();

            TextBox helpTextBox = new TextBox();
            helpTextBox.Multiline = true;
            helpTextBox.Dock = DockStyle.Fill;
            helpTextBox.ReadOnly = true;

            // ������ ���������� ����� �������
            string helpFilePath = "help.txt";
            if (File.Exists(helpFilePath))
            {
                string helpText = File.ReadAllText(helpFilePath);
                helpTextBox.Text = helpText;
            }
            else
            {
                helpTextBox.Text = "File not found: help.txt";
            }

            helpfrm.Controls.Add(helpTextBox);
            helpfrm.Show();
        }
    }
}
