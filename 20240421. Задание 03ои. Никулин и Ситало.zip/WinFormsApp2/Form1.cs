using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace WinFormsApp2
{
    public partial class MainForm : Form
    {

        string[] func_arr = { 
            "������� �� �������",
            "���������� �������� {lg}",
            "����� {sin(x)}",
            "�������� {Arcsin(x)}",
            "���������� {Arctg(x)}",
            "���������� {Arccos(x)}",
            "����������� �������� {ln(x)}",
            "������� ������ {x^(1/2)}",
            "�������������� ��������� {((1 � x) / (1 + x))^(4/5)}",
            "������� {cos(x)}",
            "���������� � ������� {x^2}",
            "������� {tg(x)}",
            "�������� �� ��������� 2 {log2(x)}"   
        };

        int index_combobox = 0;
        bool flag_error = false;
        double[] default_arguments = { -3, 3, 0.1 };


        // Tools
        ComboBox combobox1;
        Button startbtn;
        Button helpbtn;
        Button savebtn;
        ListBox listbox1;
        ListBox listbox2;
        TextBox textbox1;
        

        public MainForm()
        {
            InitializeComponent();
            this.Text = "������� �3 ��������� ������� �.�. � ������ �.�.; ����� �������� 3, ���� ���������� 21.04.2024";
            this.MinimumSize = new Size(950, 600);
        }

        private void ShowAllTools(object sender, EventArgs e)
        {
            //
            // startbtn
            //
            startbtn = new Button();
            this.Controls.Add(startbtn);
            startbtn.Click += new EventHandler(startbtn_click);
            startbtn.Text = "Start";
            startbtn.Location = new Point(20, 20);
            startbtn.Size = new Size(100, 40);
            startbtn.ForeColor = Color.Black;
            //
            // help
            //

            helpbtn = new Button();
            this.Controls.Add(helpbtn);
            helpbtn.Click += new EventHandler(helpbtn_cliclk);
            helpbtn.Text = "Help";
            helpbtn.Location = new Point(1000, 20);
            helpbtn.Size = new Size(100, 40);
            helpbtn.ForeColor = Color.Black;
            //
            // savebtn
            //
            savebtn = new Button();
            this.Controls.Add(savebtn);
            savebtn.Click += new EventHandler(savebtn_click);
            savebtn.Text = "Save";
            savebtn.Location = new Point(140, 20);
            savebtn.Size = new Size(100, 40);
            savebtn.ForeColor = Color.Black;
            //
            // combobox1
            //
            combobox1 = new ComboBox();
            this.Controls.Add(combobox1);
            combobox1.Location = new Point(20, 110);
            combobox1.Size = new Size(250, 20);
            foreach (string str in func_arr)
            {
                combobox1.Items.Add(str);
            }
            combobox1.SelectedIndex = 0;
            combobox1.SelectedIndexChanged += new EventHandler(combobox1_SelectedIndexChanged);
            //
            // listbox1
            //
            listbox1 = new ListBox();
            this.Controls.Add(listbox1);
            listbox1.Location = new Point(350, 20);
            listbox1.Size = new Size(300, 500);
            listbox1.SelectedIndexChanged += new EventHandler(listBox1_SelectedIndexChanged);
            //
            // listbox2
            //
            listbox2 = new ListBox();
            this.Controls.Add(listbox2);
            listbox2.Location = new Point(660, 20);
            listbox2.Size = new Size(300, 500);
            listbox2.SelectedIndexChanged += new EventHandler(listBox2_SelectedIndexChanged);
            //
            // textbox1
            //
            textbox1 = new TextBox();
            this.Controls.Add(textbox1);
            textbox1.Location = new Point(20, 80);
            textbox1.Size = new Size(250, 20);
            textbox1.Text = default_arguments[0].ToString() + "&*" + default_arguments[1].ToString() + "&*" + default_arguments[2].ToString();
            textbox1.TextChanged += new EventHandler(textbox1_TextChanged);


            // Pin tools to sides
            startbtn.Anchor = AnchorStyles.Left | AnchorStyles.Top;
            savebtn.Anchor = AnchorStyles.Left | AnchorStyles.Top;
            helpbtn.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            textbox1.Anchor = AnchorStyles.Left | AnchorStyles.Top;
            listbox1.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            listbox2.Anchor = AnchorStyles.Right | AnchorStyles.Top;
            combobox1.Anchor = AnchorStyles.Left | AnchorStyles.Top;
        }


        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox2.SelectedIndex = listbox1.SelectedIndex;

        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            listbox1.SelectedIndex = listbox2.SelectedIndex;
        }

        private void combobox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            index_combobox = combobox1.SelectedIndex;
        }

        // From;To;Step
        private void textbox1_TextChanged(object sender, EventArgs e)
        {
            string[] words = textbox1.Text.Split("&*");
            default_arguments = new double[3];
            int i = 0;
            flag_error = false;
            try
            {
                foreach (string word in words)
                {
                    default_arguments[i] = double.Parse(word);

                    i++;

                }
            }
            catch (Exception ex)
            {
                flag_error = true;


            }

        }

        // Start button
        private void startbtn_click(object sender, EventArgs e)
        {
            if (flag_error || index_combobox == 0)
            {
                MessageBox.Show("������! ������� �� �������");
            }
            else
            {
                listbox1.Items.Clear();
                listbox2.Items.Clear();
                for (double i = default_arguments[0]; i <= default_arguments[1]; i += default_arguments[2])
                {
                    listbox1.Items.Add(Math.Round(i, 4));
                    listbox2.Items.Add(Math.Round(functions_solver(i), 4));
                }
            }

        }

        // Help button
        private void helpbtn_cliclk(object sender, EventArgs e)
        {

            Form help_window = new Form();
            help_window.Text = "Help";
            help_window.Width = 1000;
            help_window.Height = 800;

            TextBox helpTextBox = new TextBox();
            helpTextBox.Multiline = true;
            helpTextBox.Dock = DockStyle.Fill;
            helpTextBox.ReadOnly = true;

            // ������ ���������� ����� �������
            string helpFilePath = "help.txt";
            if (File.Exists(helpFilePath))
            {
                string helpText = File.ReadAllText(helpFilePath);
                helpTextBox.Text = helpText;
            }
            else
            {
                helpTextBox.Text = "File not found: help.txt";
            }

            help_window.Controls.Add(helpTextBox);

            
            
            
            help_window.ShowDialog();

        }

        // Save button
        private void savebtn_click(object sender, EventArgs e)
        {
            if (listbox1.Items.Count == 0 || listbox2.Items.Count == 0)
            {
                MessageBox.Show("��� ������ ��� ����������.");
                return;
            }

            try
            {
                using (StreamWriter writer = new StreamWriter("output.txt"))
                {
                    for (int i = 0; i < listbox1.Items.Count; i++)
                    {
                        string argument = listbox1.Items[i].ToString();
                        string result = listbox2.Items[i].ToString();
                        writer.WriteLine($"{argument}&*{result}");
                    }
                }
                MessageBox.Show("������ ������� ��������� � ���� output.txt.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������ ��� ���������� ������: {ex.Message}");
            }
        }

        // List of functions to solve
        private double functions_solver(double x)
        {
            switch (index_combobox)
            {
                case 1:
                    return Math.Log10(x);
                case 2:
                    return Math.Sin(x);
                case 3:
                    return Math.Asin(x);
                case 4:
                    return Math.Atan(x);
                case 5:
                    return Math.Acos(x);
                case 6:
                    return Math.Log(x);
                case 7:
                    return Math.Sqrt(x);
                case 8:
                    return Math.Pow(((1.0 - x) / (1.0 + x)), 0.8);
                case 9:
                    return Math.Cos(x);
                case 10:
                    return x * x;
                case 11:
                    return Math.Tan(x);
                case 12:
                    return Math.Log2(x);
            }
            return 0;
        }

        

        // Load after all tools
        private void LoadMainForm(object sender, EventArgs e)
        {
            InitializeComponent();
            this.Text = "������� �3 ��������� ������� �.�. � ������ �.�.; ����� �������� 3, ���� ���������� 21.04.2024";
            this.MinimumSize = new Size(1150, 600);
            this.Shown += ShowAllTools;
            this.Cursor = Cursors.Hand;
            this.BackColor = SystemColors.AppWorkspace;
        }


    }
}
