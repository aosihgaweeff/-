﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;

public class DatabaseManager
{
    public string connectionString;
    private int mainDataId = -1;

    public DatabaseManager(string dbFilePath)
    {
        connectionString = $"Data Source={dbFilePath};Version=3;";
        InitializeDatabase();
    }

    private void InitializeDatabase()
    {
        using (SQLiteConnection connection = new SQLiteConnection(connectionString))
        {
            connection.Open();
            // Создаем таблицу для mainData
            string createMainDataTableQuery = @"CREATE TABLE IF NOT EXISTS MainData (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    Signature TEXT,
                                    Position TEXT,
                                    FullName TEXT,
                                    StartDate TEXT,
                                    EndDate TEXT,
                                    SheetOfIncapacity TEXT);";
            ExecuteNonQuery(connection, createMainDataTableQuery);

            // Создаем таблицу для repData
            string createRepDataTableQuery = @"CREATE TABLE IF NOT EXISTS RepData (
                                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    MainDataId INTEGER,
                                    FullName TEXT,
                                    Date TEXT,
                                    Type TEXT,
                                    ClassName TEXT,
                                    FOREIGN KEY (MainDataId) REFERENCES MainData(id));";
            ExecuteNonQuery(connection, createRepDataTableQuery);
        }
    }

    public void InsertMainData(Dictionary<string, string> mainData)
    {
        using (SQLiteConnection connection = new SQLiteConnection(connectionString))
        {
            connection.Open();

            string insertQuery = @"INSERT INTO MainData (Signature, Position, FullName, StartDate, EndDate, SheetOfIncapacity) 
                                   VALUES (@Signature, @Position, @FullName, @StartDate, @EndDate, @SheetOfIncapacity);";
            SQLiteCommand command = new SQLiteCommand(insertQuery, connection);
            command.Parameters.AddWithValue("@Signature", mainData["Подпись"]);
            command.Parameters.AddWithValue("@Position", mainData["Должность"]);
            command.Parameters.AddWithValue("@FullName", mainData["ФИО"]);
            command.Parameters.AddWithValue("@StartDate", mainData["НачальнаяДата"]);
            command.Parameters.AddWithValue("@EndDate", mainData["КонечнаяДата"]);
            command.Parameters.AddWithValue("@SheetOfIncapacity", mainData["ЛистНетрудоспособности"]);
            command.ExecuteNonQuery();

            // Получаем id после вставки
            insertQuery = "SELECT last_insert_rowid()";
            command = new SQLiteCommand(insertQuery, connection);
            mainDataId = Convert.ToInt32(command.ExecuteScalar());
        }
    }

    public void InsertRepData(Dictionary<string, List<(string, string, string)>> repData)
    {
        using (SQLiteConnection connection = new SQLiteConnection(connectionString))
        {
            connection.Open();

            foreach (var kvp in repData)
            {
                string teacherName = kvp.Key;

                foreach (var lessonData in kvp.Value)
                {
                    string insertQuery = @"INSERT INTO RepData (MainDataId,FullName, Date, Type, ClassName) 
                                          VALUES (@MainDataId, @FullName, @Date, @Type, @ClassName);";

                    SQLiteCommand command = new SQLiteCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@MainDataId", mainDataId); // Используем сохраненное значение id
                    command.Parameters.AddWithValue("@FullName", teacherName);
                    command.Parameters.AddWithValue("@Date", lessonData.Item1);
                    command.Parameters.AddWithValue("@Type", lessonData.Item2);
                    command.Parameters.AddWithValue("@ClassName", lessonData.Item3);
                    command.ExecuteNonQuery();
                }
            }
        }
    }

    private void ExecuteNonQuery(SQLiteConnection connection, string query)
    {
        using (SQLiteCommand command = new SQLiteCommand(query, connection))
        {
            command.ExecuteNonQuery();
        }
    }

    public int GetReplacementCount(SQLiteConnection connection, string fullName)
    {
        string query = "SELECT COUNT(*) FROM RepData WHERE FullName = @FullName";
        using (SQLiteCommand command = new SQLiteCommand(query, connection))
        {
            command.Parameters.AddWithValue("@FullName", fullName);
            object result = command.ExecuteScalar();
            return Convert.ToInt32(result);
        }
    }
}
