﻿using Microsoft.Office.Interop.Word;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using WordApp = Microsoft.Office.Interop.Word.Application;

namespace eWExtractor
{
    public class WordExtractor
    {

        public static Dictionary<string, string> GetExtractedMainText(string filePath)
        {
            string extractedText = ExtractTextFromWordDocument(filePath);
            var extractedGeneralData = ExtractDataFromMainText(extractedText);
            return extractedGeneralData;
        }

        public static Dictionary<string, List<(string, string, string)>> GetExtractedAddText(string filePath)
        {

            string extractedText = ExtractTextFromWordDocument(filePath);
            string cuttedText = GetCuttedText(extractedText);

            // Выводим сообщение о завершении извлечения текста

            var extractedReplacementData = ExtractDataFromAddText(cuttedText);
            return extractedReplacementData;
        }


        public static void SaveDataToWord(string filePath, Dictionary<string, string> mainData, Dictionary<string, List<(string, string, string)>> repData)
        {
            // Выводим сообщение о начале процесса
            try
            {
                // Сохраняем текст в файл
                string templateFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Temple.docx");
                string outputFilePath = Path.Combine(Path.GetDirectoryName(filePath), Path.GetFileNameWithoutExtension(filePath) + "_Extracted.docx");
                FillTemplate(templateFilePath, outputFilePath, mainData, repData);

                // Выводим сообщение о завершении процесса и пути к сохраненному файлу
                MessageBox.Show($"Процесс завершен. Извлеченный текст сохранен в файле:\n{outputFilePath}", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Выводим сообщение об ошибке, если что-то пошло не так
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        static string GetCuttedText(string extractedText)
        {
            int startIndex = extractedText.IndexOf("нагрузки:");
            int endIndex = extractedText.IndexOf("УиЗИ");
            return extractedText.Substring(startIndex, endIndex - startIndex).Trim();
        }

        static string ExtractTextFromWordDocument(string filePath)
        {
            // Create an instance of Word Application
            Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();

            // Define missing object to use as optional parameters
            object missing = System.Reflection.Missing.Value;

            // Open the document
            Document doc = wordApp.Documents.Open(filePath, ref missing, ref missing, ref missing,
                                                    ref missing, ref missing, ref missing, ref missing,
                                                    ref missing, ref missing, ref missing, ref missing,
                                                    ref missing, ref missing, ref missing, ref missing);

            // Read the text from the document
            string text = "";
            foreach (Paragraph paragraph in doc.Paragraphs)
            {
                text += paragraph.Range.Text + Environment.NewLine;
            }

            // Close the document and application
            doc.Close();
            wordApp.Quit();

            return text;
        }


        static Dictionary<string, string> ExtractDataFromMainText(string extractedText)
        {
            Dictionary<string, string> data = new Dictionary<string, string>();

            // Кому на подпись документ
            if (extractedText.Contains("Гречишникову В.А."))
            {
                /*data["MP"] = "Зам. директора ИТТСУ^pпо учебной работе,^pд.т.н., профессору^pГречишникову В.А.".TrimStart();*/
                data["Подпись"] = "Гречишникову В.А.";
            }
            else if (extractedText.Contains("Бестемьянову П.Ф."))
            {
                /*data["На подпись"] = "Директору ИТТСУ^pБестемьянову П.Ф.".TrimStart();*/
                data["Подпись"] = "Бестемьянову П.Ф.";
            }

            // Кто заболел
            string pattern = @"(?<Должность>(?:доцент[а]*|профессор[а]*|старшего преподавателя))\s+(?<Фамилия>\p{Lu}\p{L}+)(?:\s+(?<Инициалы>\p{Lu}\.\p{Lu}\.)?)?";
            Match match = Regex.Match(extractedText, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                string position = match.Groups["Должность"].Value.Trim();
                data["Должность"] = position;

                string lastName = match.Groups["Фамилия"].Value.Trim();
                string initials = match.Groups["Инициалы"].Value.Trim();

                if (!string.IsNullOrEmpty(initials))
                {
                    data["ФИО"] = $"{lastName} {initials}";
                }
                else
                {
                    data["ФИО"] = lastName;
                }
            }

            // Даты болезни
            pattern = @"с\s+(?:период\s+)?(?<НачальнаяДата>\d{1,2}\s+\p{L}+\s+\d{4}|\d{2}\.\d{2}\.\d{4})\s+(?:по|–|-)\s+(?<КонечнаяДата>\d{1,2}\s+\p{L}+\s+\d{4}|\d{2}\.\d{2}\.\d{4})\s+г\.";
            match = Regex.Match(extractedText, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                data["НачальнаяДата"] = match.Groups["НачальнаяДата"].Value.Trim();
                data["КонечнаяДата"] = match.Groups["КонечнаяДата"].Value.Trim();
            }

            // Содержимое листка нетрудоспособности
            pattern = @"\(([^)]*)\)";
            match = Regex.Match(extractedText, pattern);
            if (match.Success)
            {
                string sickLeaveNote = match.Groups[1].Value.Trim();
                data["ЛистНетрудоспособности"] = sickLeaveNote;
            }

            return data;
        }


        static Dictionary<string, List<(string Date, string LessonType, string Group)>> ExtractDataFromAddText(string extractedText)
        {
            var data = new Dictionary<string, List<(string Date, string LessonType, string Group)>>();

            // Разделение текста по строкам
            string[] lines = extractedText.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            string currentFullName = null;
            string dateOfReplacement = null; // Дата замены занятия
            foreach (string line in lines)
            {
                // Если строка содержит "Доцент" или "Профессор", то это новый преподаватель
                if (line.Contains("Доцент") || line.Contains("Профессор") || line.Contains("Старший преподаватель"))
                {
                    currentFullName = line.Trim();
                    data[currentFullName] = new List<(string Date, string LessonType, string Group)>();
                }
                // Если строка содержит дату и информацию о замене занятия
                else if (line.Contains(","))
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 2)
                    {
                        string[] details = parts[1].Split('=');
                        if (details.Length == 2)
                        {
                            string[] lessonDetails = details[0].Trim().Split();
                            if (lessonDetails.Length >= 4)
                            {
                                dateOfReplacement = parts[0].Trim(); // Записываем дату замены занятия
                                string lessonType = "неизвестно"; // По умолчанию, если тип занятия не определен

                                // Проверяем тип занятия
                                foreach (string detail in lessonDetails)
                                {
                                    if (detail.Contains("лекция"))
                                    {
                                        lessonType = "лекция";
                                        break;
                                    }
                                    else if (detail.Contains("лабораторная") || detail.Contains("лабораторные"))
                                    {
                                        lessonType = "лабораторная";
                                        break;
                                    }
                                    else if (detail.Contains("практическое"))
                                    {
                                        lessonType = "практическое занятие";
                                        break;
                                    }
                                    else if (detail.Contains("экзамен"))
                                    {
                                        lessonType = "экзамен";
                                        break;
                                    }
                                    else if (detail.Contains("консультация"))
                                    {
                                        lessonType = "консультация";
                                        break;
                                    }
                                }

                                string group = "";

                                // Извлекаем группу из строки lessonDetails
                                for (int i = 3; i < lessonDetails.Length; i++)
                                {
                                    if (lessonDetails[i].Contains("-")) // Проверяем, содержит ли элемент "-"
                                    {
                                        group = lessonDetails[i]; // Если содержит, присваиваем это значение переменной group
                                        break; // Заканчиваем цикл после нахождения группы
                                    }
                                }

                                if (!string.IsNullOrEmpty(currentFullName) && data.ContainsKey(currentFullName))
                                {
                                    // Добавляем данные в список текущего преподавателя
                                    data[currentFullName].Add((dateOfReplacement, lessonType, group));
                                }
                            }
                        }
                    }
                }
                // Если строка содержит "Итого:"
                else if (line.Contains("Итого:"))
                {
                    break; // Останавливаем парсинг после обработки всех данных
                }
            }

            return data;
        }


        static void FillTemplate(string templateFilePath, string outputFilePath, Dictionary<string, string> extractedGeneralData, Dictionary<string, List<(string Date, string LessonType, string Group)>> extractedReplacementData)
        {
            WordApp wordApp = new WordApp();
            Document doc = wordApp.Documents.Open(templateFilePath);

            // Заменяем плейсхолдер для общей информации
            foreach (var kvp in extractedGeneralData)
            {
                string key = kvp.Key;
                string value = kvp.Value;

                // Проверяем, является ли ключ "Подпись"
                if (key == "Подпись")
                {
                    // Проверяем значение и заменяем в соответствии с именем
                    if (value == "Гречишникову В.А.")
                    {
                        value = "Зам. директора ИТТСУ^pпо учебной работе,^pд.т.н., профессору^pГречишникову В.А.".TrimStart();
                    }
                    else if (value == "Бестемьянову П.Ф.")
                    {
                        value = "Директору ИТТСУ^pБестемьянову П.Ф.".TrimStart();
                    }
                }

                // Заменяем значение в документе
                FindAndReplace(wordApp, doc, $"[{key}]", value);
            }

            // Находим плейсхолдер и устанавливаем выравнивание по правому краю
            Microsoft.Office.Interop.Word.Range range = doc.Content;
            range.Find.ClearFormatting();
            range.Find.Text = "[repData]";


            StringBuilder allReplacementData = new StringBuilder();
            foreach (var kvp in extractedReplacementData)
            {
                string teacherName = kvp.Key;


                // Добавляем имя преподавателя
                allReplacementData.AppendLine(teacherName.PadRight(50));

                int workHours = 0;
                string workMonth = "";
                foreach (var lessonData in kvp.Value)
                {
                    // Выводим данные о замененных занятиях выровненными по правому краю с отступом
                    allReplacementData.AppendLine($"\t\t{lessonData.Date}, {lessonData.LessonType} в группе {lessonData.Group} = 2 часа");
                    workHours += 2;
                    workMonth = GetMonthName(lessonData.Date);
                }

                allReplacementData.AppendLine("________________________".PadLeft(105));
                allReplacementData.AppendLine($"{workMonth} - {workHours} ч.".PadLeft(120));
            }

            // Заменяем плейсхолдер [ExtractDataFromText2] на собранные данные о замененных занятиях
            InsertTextInDocument(wordApp, doc, "[repData]", allReplacementData.ToString());


            doc.SaveAs(outputFilePath);
            doc.Close();
            wordApp.Quit();
        }


        static string GetMonthName(string date)
        {
            DateTime dateTime = DateTime.ParseExact(date, "dd.MM.yyyy", CultureInfo.InvariantCulture);
            string monthName = dateTime.ToString("MMMM", CultureInfo.GetCultureInfo("ru-RU"));
            return char.ToUpper(monthName[0]) + monthName.Substring(1);
        }

        static void InsertTextInDocument(WordApp wordApp, Document doc, string placeholder, string text)
        {
            foreach (Microsoft.Office.Interop.Word.Range range in doc.StoryRanges)
            {
                range.Find.ClearFormatting();
                range.Find.Text = placeholder;

                while (range.Find.Execute())
                {
                    range.Text = text;
                }
            }
        }


        static void FindAndReplace(WordApp wordApp, Document doc, string findText, string replaceText)
        {
            foreach (Microsoft.Office.Interop.Word.Range range in doc.StoryRanges)
            {
                range.Find.ClearFormatting();

                range.Find.Execute(FindText: findText, ReplaceWith: replaceText, Replace: WdReplace.wdReplaceAll);
            }
        }

    }
}
