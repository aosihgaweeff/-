﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Office.Interop.Excel;
using ExcelApp = Microsoft.Office.Interop.Excel.Application;

namespace eWExtractor
{
    public class ExcelExtractor
    {
        // Получение основных данных из файла Excel
        public static Dictionary<string, string> GetExtractedMainData(string filePath)
        {
            Dictionary<string, string> extractedData = new Dictionary<string, string>();

            // Создание экземпляра приложения Excel
            ExcelApp excelApp = new ExcelApp();

            // Открытие файла Excel
            Workbook workbook = excelApp.Workbooks.Open(filePath);

            // Получение первого листа рабочей книги
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];

            // Чтение данных из необходимых ячеек и добавление их в словарь
            extractedData["Подпись"] = GetCellValue(worksheet.Cells[1, 1]);
            extractedData["Должность"] = GetCellValue(worksheet.Cells[2, 1]);
            extractedData["ФИО"] = GetCellValue(worksheet.Cells[3, 1]);
            extractedData["НачальнаяДата"] = GetCellValue(worksheet.Cells[4, 1]);
            extractedData["КонечнаяДата"] = GetCellValue(worksheet.Cells[5, 1]);
            extractedData["ЛистНетрудоспособности"] = GetCellValue(worksheet.Cells[6, 1]);

            // Закрытие книги Excel и приложения Excel
            workbook.Close(false);
            excelApp.Quit();

            return extractedData;
        }

        // Получение дополнительных данных из файла Excel
        public static Dictionary<string, List<(string, string, string)>> GetExtractedAddData(string filePath)
        {
            Dictionary<string, List<(string, string, string)>> extractedData = new Dictionary<string, List<(string, string, string)>>();

            // Создание экземпляра приложения Excel
            ExcelApp excelApp = new ExcelApp();

            // Открытие файла Excel
            Workbook workbook = excelApp.Workbooks.Open(filePath);

            // Получение второго листа рабочей книги
            Worksheet worksheet = null;
            if (workbook.Sheets.Count >= 2)
            {
                worksheet = (Worksheet)workbook.Sheets[2];
            }
            else
            {
                // Обработка ситуации, когда в рабочей книге нет второго листа
                // Например, можно выбросить исключение или записать сообщение в лог
                Console.WriteLine("В рабочей книге отсутствует второй лист.");
            }

            // Чтение данных из необходимых ячеек и добавление их в словарь
            int rowCount = worksheet.UsedRange.Rows.Count;
            for (int i = 1; i <= rowCount; i++)
            {
                string teacherName = GetCellValue(worksheet.Cells[i, 1]);
                string date = GetCellValue(worksheet.Cells[i, 2]);
                string lessonType = GetCellValue(worksheet.Cells[i, 3]);
                string group = GetCellValue(worksheet.Cells[i, 4]);

                if (!extractedData.ContainsKey(teacherName))
                {
                    extractedData[teacherName] = new List<(string, string, string)>();
                }

                extractedData[teacherName].Add((date, lessonType, group));
            }

            // Закрытие книги Excel и приложения Excel
            workbook.Close(false);
            excelApp.Quit();

            return extractedData;
        }

        // Вспомогательный метод для обработки значений ячеек и возврата строки
        private static string GetCellValue(object cellValue)
        {
            return cellValue != null ? cellValue.ToString() : string.Empty;
        }

        // Сохранение данных в файл Excel
        public static void SaveDataToExcel(string filePath, Dictionary<string, string> mainData, Dictionary<string, List<(string, string, string)>> repData)
        {
            // Создание нового экземпляра приложения Excel
            Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();

            // Открытие новой рабочей книги Excel
            Microsoft.Office.Interop.Excel.Workbook workbook = excelApp.Workbooks.Add();

            // Получение первого листа рабочей книги Excel
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)workbook.Sheets[1];

            // Запись основных данных в ячейки первого листа
            int row = 1;
            foreach (var kvp in mainData)
            {
                ((Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 1]).Value = kvp.Value;
                row++;
            }

            // Запись дополнительных данных в ячейки первого листа под основными данными
            row += 2; // Пропуск двух строк для разделения
            foreach (var kvp in repData)
            {
                string teacherName = kvp.Key;
                foreach (var data in kvp.Value)
                {
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 1]).Value = teacherName;
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 2]).Value = data.Item1;
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 3]).Value = data.Item2;
                    ((Microsoft.Office.Interop.Excel.Range)worksheet.Cells[row, 4]).Value = data.Item3;
                    row++;
                }
            }

            // Изменение пути к файлу для изменения расширения на .xlsx
            string newFilePath = Path.ChangeExtension(filePath, "xlsx");

            // Сохранение рабочей книги Excel с измененным путем к файлу
            workbook.SaveAs(newFilePath);

            // Закрытие рабочей книги Excel и приложения Excel
            workbook.Close();
            excelApp.Quit();
        }
    }
}
