﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace eWExtractor
{


    public partial class ChartForm : Form
    {
        DatabaseManager dbManager = new DatabaseManager("MyDatabase.sqlite");
        Dictionary<string, int> data;

        public ChartForm()
        {
            InitializeComponent();
            data = GetReplacementInfo();
            // Вызываем метод для отображения данных на графике
            DisplayDataOnChart();
        }

        private void DisplayDataOnChart()
        {
            // Очищаем график перед добавлением новых данных
            chart1.Series.Clear();

            // Создаем новую серию для графика
            Series series = new Series("Часы замены");
            series.ChartType = SeriesChartType.Column; // Устанавливаем тип диаграммы на столбчатую

            // Добавляем данные из словаря на график
            int i = 0;
            foreach (var kvp in data)
            {
                // Добавляем точку данных в серию с уникальным значением X
                series.Points.Add(new DataPoint(i, kvp.Value) { AxisLabel = kvp.Key });
                i++; // Увеличиваем значение i для следующей точки данных
            }

            // Добавляем серию на график
            chart1.Series.Add(series);

            // Настраиваем ось Y для автоматического масштабирования
            chart1.ChartAreas[0].AxisY.Minimum = 0;
            chart1.ChartAreas[0].AxisY.Maximum = 100;
        }

        private Dictionary<string, int> GetReplacementInfo()
        {
            Dictionary<string, int> replacementInfo = new Dictionary<string, int>();

            // Подключаемся к базе данных SQLite
            using (SQLiteConnection connection = new SQLiteConnection(dbManager.connectionString))
            {
                connection.Open();

                // Получаем уникальные значения FullName из таблицы RepData
                string query = "SELECT DISTINCT FullName FROM RepData";
                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    using (SQLiteDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string fullName = reader.GetString(0);
                            // Подсчитываем количество записей для каждого преподавателя в таблице RepData
                            int count = dbManager.GetReplacementCount(connection, fullName);
                            // Умножаем количество записей на 2
                            int replacementHours = count * 2;
                            // Добавляем информацию в словарь
                            replacementInfo.Add(fullName, replacementHours);
                        }
                    }
                }
            }

            return replacementInfo;
        }
    }
}