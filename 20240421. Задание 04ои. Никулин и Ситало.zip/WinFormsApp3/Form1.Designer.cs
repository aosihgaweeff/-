﻿namespace WinFormsApp3
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            frstMonthCalendar = new MonthCalendar();
            scndMonthCalendar = new MonthCalendar();
            savebtn = new Button();
            checkbtn = new Button();
            closebtn = new Button();
            resizebtn = new Button();
            minbtn = new Button();
            listBox1 = new ListBox();
            updatebtn = new Button();
            SuspendLayout();
            // 
            // monthCalendar1
            // 
            frstMonthCalendar.Location = new Point(60, 53);
            frstMonthCalendar.Name = "monthCalendar1";
            frstMonthCalendar.TabIndex = 0;
            // 
            // monthCalendar2
            // 
            scndMonthCalendar.Location = new Point(369, 53);
            scndMonthCalendar.Name = "monthCalendar2";
            scndMonthCalendar.TabIndex = 1;
            // 
            // button1
            // 
            savebtn.Location = new Point(101, 272);
            savebtn.Name = "button1";
            savebtn.Size = new Size(179, 29);
            savebtn.TabIndex = 2;
            savebtn.Text = "Сохранить Дату";
            savebtn.UseVisualStyleBackColor = true;
            savebtn.Click += SaveBtnClick;
            // 
            // button2
            // 
            checkbtn.Location = new Point(353, 409);
            checkbtn.Name = "button2";
            checkbtn.Size = new Size(94, 29);
            checkbtn.TabIndex = 3;
            checkbtn.Text = "Обновить";
            checkbtn.UseVisualStyleBackColor = true;
            checkbtn.Click += UpdateBtnClick;
            // 
            // button3
            // 
            closebtn.Location = new Point(674, 12);
            closebtn.Name = "button3";
            closebtn.Size = new Size(40, 29);
            closebtn.TabIndex = 0;
            closebtn.Text = "X";
            closebtn.UseVisualStyleBackColor = true;
            closebtn.Click += CloseBtnClick;
            // 
            // button4
            // 
            resizebtn.Location = new Point(720, 12);
            resizebtn.Name = "button4";
            resizebtn.Size = new Size(40, 29);
            resizebtn.TabIndex = 1;
            resizebtn.Text = "□";
            resizebtn.UseVisualStyleBackColor = true;
            resizebtn.Click += ResizeBtnClick;
            // 
            // button5
            // 
            minbtn.Location = new Point(766, 12);
            minbtn.Name = "button5";
            minbtn.Size = new Size(40, 29);
            minbtn.TabIndex = 2;
            minbtn.Text = "_";
            minbtn.UseVisualStyleBackColor = true;
            minbtn.Click += MinBtnClick;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(369, 272);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(262, 124);
            listBox1.TabIndex = 4;
            // 
            // button6
            // 
            updatebtn.Location = new Point(466, 409);
            updatebtn.Name = "button6";
            updatebtn.Size = new Size(215, 29);
            updatebtn.TabIndex = 5;
            updatebtn.Text = "Узнать возраст человека";
            updatebtn.UseVisualStyleBackColor = true;
            updatebtn.Click += CheckBtnClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(819, 450);
            Controls.Add(updatebtn);
            Controls.Add(listBox1);
            Controls.Add(minbtn);
            Controls.Add(resizebtn);
            Controls.Add(closebtn);
            Controls.Add(checkbtn);
            Controls.Add(savebtn);
            Controls.Add(scndMonthCalendar);
            Controls.Add(frstMonthCalendar);
            Name = "Form1";
            Text = "Form1";
            Load += LoadMainForm;
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.MonthCalendar frstMonthCalendar;
        private System.Windows.Forms.MonthCalendar scndMonthCalendar;
        private System.Windows.Forms.Button savebtn;
        private System.Windows.Forms.Button checkbtn;
        private Button closebtn;
        private Button resizebtn;
        private Button minbtn;
        private ListBox listBox1;
        private Button updatebtn;
    }
}
