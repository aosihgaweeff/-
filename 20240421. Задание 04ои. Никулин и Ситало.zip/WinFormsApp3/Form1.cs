using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;

namespace WinFormsApp3
{
    public partial class MainForm : Form
    {
        bool fsize = true;
        List<string> people = new List<string>();

        public MainForm()
        {
            InitializeComponent();
            this.Text = "������� �4 ��������� ������� �.�. � ������ �.�.; ����� �������� 3, ���� ���������� 21.04.2024";
            this.ControlBox = false;


            string[] existingDates = File.ReadAllLines("saved_dates.txt");
            people.AddRange(existingDates);
        }

        private void LoadMainForm(object sender, EventArgs e)
        {
            string[] lines = File.ReadAllLines("help_info.txt");
            ToolTip toolTip = new ToolTip();

            foreach (string line in lines)
            {
                string[] parts = line.Split('=');
                if (parts.Length == 2)
                {
                    string controlName = parts[0];
                    string helpText = parts[1];
                    Control control = Controls.Find(controlName, true).FirstOrDefault();
                    if (control != null)
                    {
                        toolTip.SetToolTip(control, helpText);
                    }
                }
            }

            
            foreach (string person in people)
            {
                listBox1.Items.Add(person);
            }

        }

        private void SaveBtnClick(object sender, EventArgs e)
        {
            DateTime selectedDate = frstMonthCalendar.SelectionStart;

            string filePath = "saved_dates.txt";

            try
            {
                people.Add(selectedDate.ToString("yyyy-MM-dd"));

                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(selectedDate.ToString("yyyy-MM-dd"));
                }

                MessageBox.Show("���� ������� ��������� � ����.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������ ��� ���������� ���� � ����: {ex.Message}");
            }
        }

        private void UpdateBtnClick(object sender, EventArgs e)
        {
            try
            {
                listBox1.Items.Clear();

                foreach (string person in people)
                {
                    listBox1.Items.Add(person);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"������: {ex.Message}");
            }
        }

        private void CheckBtnClick(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string selectedDateStr = listBox1.SelectedItem.ToString();
                DateTime selectedDate = DateTime.Parse(selectedDateStr);

                scndMonthCalendar.SetDate(selectedDate);

                int years = DateTime.Today.Year - selectedDate.Year;
                if (DateTime.Today.Month < selectedDate.Month || (DateTime.Today.Month == selectedDate.Month && DateTime.Today.Day < selectedDate.Day))
                {
                    years--;
                }

                MessageBox.Show($"�������� ����������� {years} ���.");
            }
            else
            {
                MessageBox.Show("�������� ���� �� ������.");
            }
        }

        private void CloseBtnClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResizeBtnClick(object sender, EventArgs e)
        {

            if (fsize)
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Maximized;
                fsize = false;
            }
            else
            {
                this.TopMost = true;
                this.WindowState = FormWindowState.Normal;
                fsize = true;
            }
        }

        private void MinBtnClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    }
}
